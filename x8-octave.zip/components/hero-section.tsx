import type { ClassInfo } from "@/lib/db/schema"
import { MapPin, User, Quote } from "lucide-react"

export function HeroSection({ info }: { info: ClassInfo | null }) {
  const name = info?.className || "Kelas Kita"
  const tagline = info?.tagline || "Kelas kompak, kreatif, dan siap berprestasi"

  return (
    <section id="top" className="relative overflow-hidden">
      <div
        className="absolute inset-0 -z-10 bg-cover bg-center opacity-15"
        style={{ backgroundImage: "url(/images/class-hero.png)" }}
        aria-hidden="true"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-primary/10 to-background" aria-hidden="true" />

      <div className="mx-auto max-w-5xl px-4 py-16 md:py-24">
        <span className="inline-flex items-center rounded-full bg-accent px-3 py-1 text-xs font-600 text-accent-foreground">
          Website Resmi Kelas
        </span>
        <h1 className="mt-4 text-balance font-heading text-4xl font-800 leading-tight md:text-6xl">
          {name}
        </h1>
        <p className="mt-4 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
          {tagline}
        </p>

        <div className="mt-8 flex flex-wrap gap-3">
          {info?.homeroomTeacher && (
            <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm">
              <User className="h-4 w-4 text-primary" />
              <span className="text-muted-foreground">Wali Kelas:</span>
              <span className="font-600">{info.homeroomTeacher}</span>
            </div>
          )}
          {info?.room && (
            <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm">
              <MapPin className="h-4 w-4 text-primary" />
              <span className="text-muted-foreground">Ruang:</span>
              <span className="font-600">{info.room}</span>
            </div>
          )}
        </div>

        {info?.motto && (
          <div className="mt-8 flex items-start gap-3 rounded-2xl border border-border bg-card/60 p-5">
            <Quote className="h-5 w-5 shrink-0 text-accent" />
            <p className="font-heading text-lg font-600 italic">{info.motto}</p>
          </div>
        )}
      </div>
    </section>
  )
}
