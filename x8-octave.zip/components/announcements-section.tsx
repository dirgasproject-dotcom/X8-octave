import type { Announcement } from "@/lib/db/schema"
import { SectionHeading } from "./about-section"
import { Pin } from "lucide-react"

const CATEGORY_LABEL: Record<string, string> = {
  umum: "Umum",
  akademik: "Akademik",
  kegiatan: "Kegiatan",
}

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(date))
}

export function AnnouncementsSection({ announcements }: { announcements: Announcement[] }) {
  return (
    <section id="pengumuman" className="scroll-mt-20 border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-5xl px-4 py-14">
        <SectionHeading eyebrow="Pengumuman" title="Info & pengumuman terbaru" />

        {announcements.length === 0 ? (
          <p className="mt-6 text-muted-foreground">Belum ada pengumuman. Tambahkan lewat menu Kelola.</p>
        ) : (
          <div className="mt-8 flex flex-col gap-4">
            {announcements.map((a) => (
              <article
                key={a.id}
                className={`rounded-2xl border bg-card p-5 ${
                  a.pinned ? "border-primary/50 ring-1 ring-primary/20" : "border-border"
                }`}
              >
                <div className="flex flex-wrap items-center gap-2">
                  {a.pinned && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-600 text-primary">
                      <Pin className="h-3 w-3" /> Disematkan
                    </span>
                  )}
                  <span className="rounded-full bg-accent px-2.5 py-0.5 text-xs font-600 text-accent-foreground">
                    {CATEGORY_LABEL[a.category] || a.category}
                  </span>
                  <span className="ml-auto text-xs text-muted-foreground">{formatDate(a.createdAt)}</span>
                </div>
                <h3 className="mt-3 font-heading text-lg font-700">{a.title}</h3>
                {a.content && (
                  <p className="mt-1 text-pretty leading-relaxed text-muted-foreground">{a.content}</p>
                )}
              </article>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
