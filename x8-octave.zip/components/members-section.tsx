import type { Member } from "@/lib/db/schema"
import { SectionHeading } from "./about-section"

function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase())
    .join("")
}

function MemberCard({ member }: { member: Member }) {
  const isTeacher = member.role === "guru"
  return (
    <div className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4">
      <div
        className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full font-heading text-sm font-700 ${
          isTeacher ? "bg-accent text-accent-foreground" : "bg-primary/15 text-primary"
        }`}
        aria-hidden="true"
      >
        {initials(member.name)}
      </div>
      <div className="min-w-0">
        <p className="truncate font-600 leading-tight">{member.name}</p>
        {member.position && <p className="text-sm font-500 text-primary">{member.position}</p>}
        {member.bio && <p className="mt-0.5 truncate text-sm text-muted-foreground">{member.bio}</p>}
      </div>
    </div>
  )
}

export function MembersSection({ members }: { members: Member[] }) {
  const teachers = members.filter((m) => m.role === "guru")
  const students = members.filter((m) => m.role !== "guru")

  return (
    <section id="anggota" className="mx-auto max-w-5xl scroll-mt-20 px-4 py-14">
      <SectionHeading eyebrow="Anggota" title="Wali kelas & siswa" />

      {members.length === 0 ? (
        <p className="mt-6 text-muted-foreground">Belum ada anggota. Tambahkan lewat menu Kelola.</p>
      ) : (
        <div className="mt-8 flex flex-col gap-8">
          {teachers.length > 0 && (
            <div>
              <h3 className="mb-3 font-heading text-lg font-700">Wali Kelas</h3>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {teachers.map((m) => (
                  <MemberCard key={m.id} member={m} />
                ))}
              </div>
            </div>
          )}
          {students.length > 0 && (
            <div>
              <h3 className="mb-3 font-heading text-lg font-700">Siswa</h3>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {students.map((m) => (
                  <MemberCard key={m.id} member={m} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  )
}
