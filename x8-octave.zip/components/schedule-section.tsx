import type { Schedule } from "@/lib/db/schema"
import { SectionHeading } from "./about-section"
import { Clock } from "lucide-react"

const DAY_ORDER = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]

export function ScheduleSection({ schedules }: { schedules: Schedule[] }) {
  const byDay = DAY_ORDER.map((day) => ({
    day,
    items: schedules
      .filter((s) => s.day.toLowerCase() === day.toLowerCase())
      .sort((a, b) => a.startTime.localeCompare(b.startTime)),
  })).filter((g) => g.items.length > 0)

  return (
    <section id="jadwal" className="scroll-mt-20 border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-5xl px-4 py-14">
        <SectionHeading eyebrow="Jadwal" title="Jadwal pelajaran mingguan" />

        {byDay.length === 0 ? (
          <p className="mt-6 text-muted-foreground">Belum ada jadwal. Tambahkan lewat menu Kelola.</p>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2">
            {byDay.map((group) => (
              <div key={group.day} className="rounded-2xl border border-border bg-card p-5">
                <h3 className="font-heading text-lg font-700">{group.day}</h3>
                <ul className="mt-4 flex flex-col gap-3">
                  {group.items.map((item) => (
                    <li key={item.id} className="flex items-start gap-3 rounded-xl bg-secondary/60 p-3">
                      <div className="flex items-center gap-1.5 rounded-lg bg-primary/10 px-2 py-1 text-xs font-600 text-primary">
                        <Clock className="h-3.5 w-3.5" />
                        {item.startTime}
                        {item.endTime ? `–${item.endTime}` : ""}
                      </div>
                      <div className="min-w-0">
                        <p className="font-600 leading-tight">{item.subject}</p>
                        {item.teacher && (
                          <p className="text-sm text-muted-foreground">{item.teacher}</p>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
