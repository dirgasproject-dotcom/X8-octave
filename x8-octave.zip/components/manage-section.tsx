import type { Announcement, ClassInfo, Member, Schedule } from "@/lib/db/schema"
import {
  addAnnouncement,
  addMember,
  addSchedule,
  deleteAnnouncement,
  deleteMember,
  deleteSchedule,
  updateClassInfo,
} from "@/app/actions/class"
import { SectionHeading } from "./about-section"
import { SubmitButton } from "./submit-button"
import { Trash2 } from "lucide-react"

const inputClass =
  "w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
const labelClass = "mb-1 block text-sm font-600"

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h3 className="font-heading text-lg font-700">{title}</h3>
      <div className="mt-4">{children}</div>
    </div>
  )
}

function DeleteButton({ action, id }: { action: (fd: FormData) => Promise<void>; id: number }) {
  return (
    <form action={action}>
      <input type="hidden" name="id" value={id} />
      <button
        type="submit"
        aria-label="Hapus"
        className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
      >
        <Trash2 className="h-4 w-4" />
      </button>
    </form>
  )
}

export function ManageSection({
  info,
  members,
  schedules,
  announcements,
}: {
  info: ClassInfo | null
  members: Member[]
  schedules: Schedule[]
  announcements: Announcement[]
}) {
  return (
    <section id="kelola" className="mx-auto max-w-5xl scroll-mt-20 px-4 py-14">
      <SectionHeading eyebrow="Kelola" title="Perbarui data kelas" />
      <p className="mt-3 max-w-2xl leading-relaxed text-muted-foreground">
        Semua perubahan langsung tersimpan ke database dan tampil di halaman ini.
      </p>

      <div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-2">
        {/* Info kelas */}
        <Card title="Info Kelas">
          <form action={updateClassInfo} className="flex flex-col gap-3">
            <div>
              <label className={labelClass} htmlFor="className">Nama Kelas</label>
              <input id="className" name="className" className={inputClass} defaultValue={info?.className ?? ""} />
            </div>
            <div>
              <label className={labelClass} htmlFor="tagline">Tagline</label>
              <input id="tagline" name="tagline" className={inputClass} defaultValue={info?.tagline ?? ""} />
            </div>
            <div>
              <label className={labelClass} htmlFor="description">Deskripsi</label>
              <textarea id="description" name="description" rows={3} className={inputClass} defaultValue={info?.description ?? ""} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={labelClass} htmlFor="homeroomTeacher">Wali Kelas</label>
                <input id="homeroomTeacher" name="homeroomTeacher" className={inputClass} defaultValue={info?.homeroomTeacher ?? ""} />
              </div>
              <div>
                <label className={labelClass} htmlFor="room">Ruang</label>
                <input id="room" name="room" className={inputClass} defaultValue={info?.room ?? ""} />
              </div>
            </div>
            <div>
              <label className={labelClass} htmlFor="motto">Motto</label>
              <input id="motto" name="motto" className={inputClass} defaultValue={info?.motto ?? ""} />
            </div>
            <SubmitButton>Simpan Info Kelas</SubmitButton>
          </form>
        </Card>

        {/* Anggota */}
        <Card title="Anggota">
          <form action={addMember} className="flex flex-col gap-3">
            <div>
              <label className={labelClass} htmlFor="m-name">Nama</label>
              <input id="m-name" name="name" required className={inputClass} placeholder="Nama lengkap" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={labelClass} htmlFor="m-role">Peran</label>
                <select id="m-role" name="role" className={inputClass} defaultValue="siswa">
                  <option value="siswa">Siswa</option>
                  <option value="guru">Guru / Wali Kelas</option>
                </select>
              </div>
              <div>
                <label className={labelClass} htmlFor="m-position">Jabatan</label>
                <input id="m-position" name="position" className={inputClass} placeholder="Ketua Kelas" />
              </div>
            </div>
            <div>
              <label className={labelClass} htmlFor="m-bio">Bio singkat</label>
              <input id="m-bio" name="bio" className={inputClass} placeholder="Hobi / catatan" />
            </div>
            <SubmitButton>Tambah Anggota</SubmitButton>
          </form>

          {members.length > 0 && (
            <ul className="mt-4 flex flex-col gap-2 border-t border-border pt-4">
              {members.map((m) => (
                <li key={m.id} className="flex items-center justify-between gap-2 rounded-lg bg-secondary/50 px-3 py-2">
                  <span className="min-w-0 truncate text-sm">
                    <span className="font-600">{m.name}</span>
                    {m.position ? ` — ${m.position}` : ""}
                  </span>
                  <DeleteButton action={deleteMember} id={m.id} />
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Jadwal */}
        <Card title="Jadwal Pelajaran">
          <form action={addSchedule} className="flex flex-col gap-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={labelClass} htmlFor="s-day">Hari</label>
                <select id="s-day" name="day" className={inputClass} defaultValue="Senin">
                  {["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"].map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className={labelClass} htmlFor="s-subject">Mata Pelajaran</label>
                <input id="s-subject" name="subject" required className={inputClass} placeholder="Matematika" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className={labelClass} htmlFor="s-start">Mulai</label>
                <input id="s-start" name="startTime" className={inputClass} placeholder="07:00" />
              </div>
              <div>
                <label className={labelClass} htmlFor="s-end">Selesai</label>
                <input id="s-end" name="endTime" className={inputClass} placeholder="08:30" />
              </div>
              <div>
                <label className={labelClass} htmlFor="s-teacher">Guru</label>
                <input id="s-teacher" name="teacher" className={inputClass} placeholder="Pak Joko" />
              </div>
            </div>
            <SubmitButton>Tambah Jadwal</SubmitButton>
          </form>

          {schedules.length > 0 && (
            <ul className="mt-4 flex flex-col gap-2 border-t border-border pt-4">
              {schedules.map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-2 rounded-lg bg-secondary/50 px-3 py-2">
                  <span className="min-w-0 truncate text-sm">
                    <span className="font-600">{s.day}</span> — {s.subject}
                    {s.startTime ? ` (${s.startTime})` : ""}
                  </span>
                  <DeleteButton action={deleteSchedule} id={s.id} />
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Pengumuman */}
        <Card title="Pengumuman">
          <form action={addAnnouncement} className="flex flex-col gap-3">
            <div>
              <label className={labelClass} htmlFor="a-title">Judul</label>
              <input id="a-title" name="title" required className={inputClass} placeholder="Judul pengumuman" />
            </div>
            <div>
              <label className={labelClass} htmlFor="a-content">Isi</label>
              <textarea id="a-content" name="content" rows={3} className={inputClass} placeholder="Tulis detail pengumuman" />
            </div>
            <div className="grid grid-cols-2 items-end gap-3">
              <div>
                <label className={labelClass} htmlFor="a-category">Kategori</label>
                <select id="a-category" name="category" className={inputClass} defaultValue="umum">
                  <option value="umum">Umum</option>
                  <option value="akademik">Akademik</option>
                  <option value="kegiatan">Kegiatan</option>
                </select>
              </div>
              <label className="flex items-center gap-2 pb-2.5 text-sm font-600">
                <input type="checkbox" name="pinned" className="h-4 w-4 rounded border-border accent-[var(--primary)]" />
                Sematkan
              </label>
            </div>
            <SubmitButton>Tambah Pengumuman</SubmitButton>
          </form>

          {announcements.length > 0 && (
            <ul className="mt-4 flex flex-col gap-2 border-t border-border pt-4">
              {announcements.map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-2 rounded-lg bg-secondary/50 px-3 py-2">
                  <span className="min-w-0 truncate text-sm font-600">{a.title}</span>
                  <DeleteButton action={deleteAnnouncement} id={a.id} />
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </section>
  )
}
