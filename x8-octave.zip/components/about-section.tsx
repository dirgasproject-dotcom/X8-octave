import type { ClassInfo } from "@/lib/db/schema"
import { Users, CalendarDays, Megaphone } from "lucide-react"

export function AboutSection({
  info,
  memberCount,
  scheduleCount,
  announcementCount,
}: {
  info: ClassInfo | null
  memberCount: number
  scheduleCount: number
  announcementCount: number
}) {
  const stats = [
    { label: "Anggota", value: memberCount, icon: Users },
    { label: "Mata Pelajaran", value: scheduleCount, icon: CalendarDays },
    { label: "Pengumuman", value: announcementCount, icon: Megaphone },
  ]

  return (
    <section id="tentang" className="mx-auto max-w-5xl scroll-mt-20 px-4 py-14">
      <SectionHeading eyebrow="Tentang" title="Kenalan dengan kelas kami" />
      <p className="mt-4 max-w-2xl text-pretty leading-relaxed text-muted-foreground">
        {info?.description || "Belum ada deskripsi kelas. Tambahkan lewat menu Kelola di bawah."}
      </p>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-6">
            <s.icon className="h-6 w-6 text-primary" />
            <p className="mt-4 font-heading text-3xl font-800">{s.value}</p>
            <p className="text-sm text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

export function SectionHeading({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div>
      <span className="text-sm font-700 uppercase tracking-wide text-primary">{eyebrow}</span>
      <h2 className="mt-1 text-balance font-heading text-2xl font-700 md:text-3xl">{title}</h2>
    </div>
  )
}
