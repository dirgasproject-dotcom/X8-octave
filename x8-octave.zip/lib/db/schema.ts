import { boolean, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core"

export const classInfo = pgTable("class_info", {
  id: serial("id").primaryKey(),
  className: text("class_name").notNull().default("Kelas"),
  tagline: text("tagline").notNull().default(""),
  description: text("description").notNull().default(""),
  homeroomTeacher: text("homeroom_teacher").notNull().default(""),
  room: text("room").notNull().default(""),
  motto: text("motto").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
})

export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull().default("siswa"),
  position: text("position").notNull().default(""),
  bio: text("bio").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  day: text("day").notNull(),
  startTime: text("start_time").notNull().default(""),
  endTime: text("end_time").notNull().default(""),
  subject: text("subject").notNull(),
  teacher: text("teacher").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull().default(""),
  category: text("category").notNull().default("umum"),
  pinned: boolean("pinned").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

export type Member = typeof members.$inferSelect
export type Schedule = typeof schedules.$inferSelect
export type Announcement = typeof announcements.$inferSelect
export type ClassInfo = typeof classInfo.$inferSelect
