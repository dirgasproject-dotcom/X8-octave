import {
  getAnnouncements,
  getClassInfo,
  getMembers,
  getSchedules,
} from "@/app/actions/class"
import { AboutSection } from "@/components/about-section"
import { AnnouncementsSection } from "@/components/announcements-section"
import { HeroSection } from "@/components/hero-section"
import { ManageSection } from "@/components/manage-section"
import { MembersSection } from "@/components/members-section"
import { ScheduleSection } from "@/components/schedule-section"
import { SiteNav } from "@/components/site-nav"

export const dynamic = "force-dynamic"

export default async function Page() {
  const [info, members, schedules, announcements] = await Promise.all([
    getClassInfo(),
    getMembers(),
    getSchedules(),
    getAnnouncements(),
  ])

  return (
    <main className="min-h-screen">
      <SiteNav className={info?.className} />
      <HeroSection info={info} />
      <AboutSection
        info={info}
        memberCount={members.length}
        scheduleCount={schedules.length}
        announcementCount={announcements.length}
      />
      <ScheduleSection schedules={schedules} />
      <MembersSection members={members} />
      <AnnouncementsSection announcements={announcements} />
      <ManageSection
        info={info}
        members={members}
        schedules={schedules}
        announcements={announcements}
      />

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-5xl flex-col items-center gap-1 px-4 py-8 text-center">
          <p className="font-heading font-700">{info?.className || "Website Kelas"}</p>
          <p className="text-sm text-muted-foreground">
            {info?.motto || "Belajar, Bertumbuh, Bersama."}
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            Dibuat dengan v0 - Website profil kelas
          </p>
        </div>
      </footer>
    </main>
  )
}
