"use server"

import { db } from "@/lib/db"
import { announcements, classInfo, members, schedules } from "@/lib/db/schema"
import { asc, desc, eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"

// ---------- Reads ----------

export async function getClassInfo() {
  const rows = await db.select().from(classInfo).limit(1)
  return rows[0] ?? null
}

export async function getMembers() {
  return db.select().from(members).orderBy(asc(members.createdAt))
}

export async function getSchedules() {
  return db.select().from(schedules).orderBy(asc(schedules.createdAt))
}

export async function getAnnouncements() {
  return db.select().from(announcements).orderBy(desc(announcements.pinned), desc(announcements.createdAt))
}

// ---------- Class info ----------

export async function updateClassInfo(formData: FormData) {
  const values = {
    className: String(formData.get("className") || "Kelas"),
    tagline: String(formData.get("tagline") || ""),
    description: String(formData.get("description") || ""),
    homeroomTeacher: String(formData.get("homeroomTeacher") || ""),
    room: String(formData.get("room") || ""),
    motto: String(formData.get("motto") || ""),
    updatedAt: new Date(),
  }

  const existing = await db.select().from(classInfo).limit(1)
  if (existing[0]) {
    await db.update(classInfo).set(values).where(eq(classInfo.id, existing[0].id))
  } else {
    await db.insert(classInfo).values(values)
  }
  revalidatePath("/")
}

// ---------- Members ----------

export async function addMember(formData: FormData) {
  const name = String(formData.get("name") || "").trim()
  if (!name) return
  await db.insert(members).values({
    name,
    role: String(formData.get("role") || "siswa"),
    position: String(formData.get("position") || ""),
    bio: String(formData.get("bio") || ""),
  })
  revalidatePath("/")
}

export async function deleteMember(formData: FormData) {
  const id = Number(formData.get("id"))
  if (!id) return
  await db.delete(members).where(eq(members.id, id))
  revalidatePath("/")
}

// ---------- Schedules ----------

export async function addSchedule(formData: FormData) {
  const day = String(formData.get("day") || "").trim()
  const subject = String(formData.get("subject") || "").trim()
  if (!day || !subject) return
  await db.insert(schedules).values({
    day,
    subject,
    startTime: String(formData.get("startTime") || ""),
    endTime: String(formData.get("endTime") || ""),
    teacher: String(formData.get("teacher") || ""),
  })
  revalidatePath("/")
}

export async function deleteSchedule(formData: FormData) {
  const id = Number(formData.get("id"))
  if (!id) return
  await db.delete(schedules).where(eq(schedules.id, id))
  revalidatePath("/")
}

// ---------- Announcements ----------

export async function addAnnouncement(formData: FormData) {
  const title = String(formData.get("title") || "").trim()
  if (!title) return
  await db.insert(announcements).values({
    title,
    content: String(formData.get("content") || ""),
    category: String(formData.get("category") || "umum"),
    pinned: formData.get("pinned") === "on",
  })
  revalidatePath("/")
}

export async function deleteAnnouncement(formData: FormData) {
  const id = Number(formData.get("id"))
  if (!id) return
  await db.delete(announcements).where(eq(announcements.id, id))
  revalidatePath("/")
}
